<!DOCTYPE html>
<html>
<head><title> MAKER'S TRIBE</title></head>
<style>
body{
  background-image: url('bgimg.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}</style>

<body>
<header style="padding:10px; border:20px;background-color:yellow;width:cover;height:100px;">
  <img style="float:left;" src="logo.jpg" alt="logo" width="100px" heigh="100 px">
  <h2 style="float:left;">MAKER'S TRIBE</h2>
</header>

<!-- php coding part  -->
<?php
  $fname = $_POST["fname"];
  $lname = $_POST['lname'];
  $Email = $_POST['Email'];
  $dob = $_POST['dob'];
  $pwd = $_POST['pwd'];
  $interest = $_POST['interest'];
  $profession = $_POST['profession'];
  $country = $_POST['country'];
  
  $servername = "127.0.0.1"; 
  $database = "mt";
  $username = "root";
  $password = "";
  $conn = mysqli_connect($servername, $username, $password, $database);
  if (!$conn) 
     die("Connection failed: " . mysqli_connect_error());
  $sql = "INSERT INTO makerstribe(fname, lname, Email, dob, pwd, interest, profession, country) VALUES ('$fname', '$lname','$Email','$dob', '$pwd' ,'$interest', '$profession', '$country')"; 
  if (mysqli_query($conn, $sql)) 
     {echo "New record created successfully";
     
  }else 
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);  
     mysqli_close($conn);
?>

<!-- php coding ends here -->

<br><br><br>
<div style="background-color:rgb(222,255,255);padding:50px;width:400px;">
<h3><a href="exist.html">LOG IN</a> (or) <a href="C:\Users\Kamaleshwaran\Desktop\makers tribe\handson.html">SIGN IN</a></h3><hr>
<form action="loginpage.php" method="post">
First name:<input type="text" name="fname" required><br>
Last name:<input type="text" name="lname" required><br>
Email:<input type="email" name="Email" required><br>
D.O.B:<input type="date" name="dob" required><br>
Password:<input type="password" name="pwd" required><br>
field of interest:<input type="text" id="interest" name="interest" required><br>
Profession:
<input type="radio" name="profession" value="student">Student
<input type="radio" name="profession" value="Employee">Employee<br>
country:<input type="text" name="country"><br>
<input type="submit">
</form>
</div>
</body>
</html>